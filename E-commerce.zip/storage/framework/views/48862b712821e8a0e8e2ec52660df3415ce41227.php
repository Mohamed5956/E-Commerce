<?php $__env->startSection('title'); ?>
    My Orders
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h4 class="text-light">Order View</h4>
                        <a href="<?php echo e(url('/orders')); ?>" class="btn btn-warning float-end">Back</a>
                    </div>
                    <div class="card-body">
                        <div class="row order-details">
                            <div class="col-md-6">
                                <h4>Shipping Details</h4>
                                <hr>
                                <label for="">First Name</label>
                                <div class="border"><?php echo e($orders->fname); ?></div>
                                <label for="">Last Name</label>
                                <div class="border"><?php echo e($orders->lname); ?></div>
                                <label for="">Email</label>
                                <div class="border"><?php echo e($orders->email); ?></div>
                                <label for="">Contact No.</label>
                                <div class="border"><?php echo e($orders->phone); ?></div>
                                <label for="">Shipping Address</label>
                                <div class="border">
                                    <?php echo e($orders->address1); ?>

                                    <?php echo e($orders->address2); ?>

                                    <?php echo e($orders->city); ?>

                                    <?php echo e($orders->state); ?>

                                    <?php echo e($orders->country); ?>

                                </div>
                                <label for="">Zip Code</label>
                                <div class="border"><?php echo e($orders->pincode); ?></div>
                            </div>

                            <div class="col-md-6">
                                <h4>Order Details</h4>
                                <hr>
                                <table class="table table-bordered">

                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Image</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->products->name); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td><?php echo e($item->price); ?></td>
                                                <td>
                                                    <img src="<?php echo e(asset('assets/uploads/products/' . $item->products->image)); ?>"
                                                        width="50px" alt="Product-image">
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <h4 class="px-2">Total : <span class="float-end"><?php echo e($orders->total_price); ?> $ </span></h4>
                                <div class="mt-5 px-2">
                                    <form action="<?php echo e(url('orders/' . $orders->id)); ?>" method="POST">
                                        <?php echo method_field('PUT'); ?>
                                        <?php echo csrf_field(); ?>
                                        <label for="">Order Status</label>
                                        <select class="form-select" name="order_status">
                                            <option <?php echo e($orders->status == '0' ? 'selected' : ''); ?> value="0">Pending</option>
                                            <option <?php echo e($orders->status == '1' ? 'selected' : ''); ?> value="1">Completed</option>
                                        </select>
                                        <button type="submit" class="btn btn-primary mt-3">Update</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/admin/orders/view.blade.php ENDPATH**/ ?>