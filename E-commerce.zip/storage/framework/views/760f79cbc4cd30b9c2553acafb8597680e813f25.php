<?php $__env->startSection('title'); ?>
    My Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5 mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3>My Profile</h3>
                        <hr>
                    </div>
                    <div class="card-body">
                        <form class="containerForm" action="<?php echo e(url('edit/'.$user->id)); ?>" method="POST">
                        <div class="row">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                            <div class="col-md-4">
                                <label for="fname">First Name</label>
                                <div class="p-2 border"> <input type="text" name="name" class="form-control"
                                    value="<?php echo e(old('name',$user->name)); ?>" >
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="lname">Last Name</label>
                                <div class="p-2 border"> <input type="text" name="lname" class="form-control"
                                    value="<?php echo e(old('lname',$user->lname)); ?>" >
                                    <span class="text-danger"><?php echo e($errors->first('lname')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="email">Email</label>
                                <div class="p-2 border"> <input type="text" name="email" class="form-control"
                                    value="<?php echo e(old('email',$user->email)); ?>" >
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="phone">Phone</label>
                                <div class="p-2 border"> <input type="text" name="phone" class="form-control"
                                    value="<?php echo e(old('phone',$user->phone)); ?>" >
                                    <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="address1">Address 1</label>
                                <div class="p-2 border"> <input type="text" name="address1" class="form-control"
                                    value="<?php echo e(old('address1',$user->address1)); ?>" >
                                    <span class="text-danger"><?php echo e($errors->first('address1')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="address2">Address 2</label>
                                <div class="p-2 border"> <input type="text" name="address2" class="form-control"
                                    value="<?php echo e(old('address2',$user->address2)); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('address2')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="city">City</label>
                                <div class="p-2 border"> <input type="text" name="city" class="form-control"
                                     value="<?php echo e(old('city',$user->city)); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="state">State</label>
                                <div class="p-2 border"> <input type="text" name="state" class="form-control"
                                    value="<?php echo e(old('state',$user->state)); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="country">Country</label>
                                <div class="p-2 border"> <input type="text" name="country" class="form-control"
                                    value="<?php echo e(old('country',$user->country)); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="pincode">Zip Code</label>
                                <div class="p-2 border">
                                     <input type="text" name="pincode" class="form-control"
                                    value="<?php echo e(old('pincode',$user->pincode)); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('pincode')); ?></span>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="float-end btn btn-warning">Update</button>
                    </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/frontend/users/index.blade.php ENDPATH**/ ?>