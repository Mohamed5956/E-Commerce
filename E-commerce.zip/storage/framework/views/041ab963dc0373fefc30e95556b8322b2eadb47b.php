<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand " href="<?php echo e(url('/')); ?>"><img class="logo"
                src="<?php echo e(asset('assets/images/logo.png')); ?>"></a>
                <div class="search-bar">
                    <form action="<?php echo e(url('searchProduct')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="input-group flex-nowrap">
                            <input type="search" class="form-control" name="search" id="search_product" placeholder="Product Name" aria-label="Username" aria-describedby="addon-wrapping">
                            <button type="submit" class="input-group-text"><i class="fa fa-search"></i></button>
                          </div>
                    </form>
                </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('category')); ?>">Category</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/cart')); ?>"><i class="fa fa-shopping-cart"></i>
                    <span class="badge badge-pill bg-success cart-count">0</span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/wishlist')); ?>"><i class="fa fa-heart"></i>
                        <span class="badge badge-pill bg-primary wish-count">0</span></a>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isGuest')): ?>

                <?php else: ?>
                <?php if(Auth::user()): ?>
                <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(url('/my-orders')); ?>">My Orders</a>
                            </li>

                            <li>
                                <a class="dropdown-item" href="<?php echo e(url('profile/'.Auth::user()->id)); ?>">My Profile</a>
                            </li>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </a>
                    </li>
                </ul>
                    <?php elseif(Route::has('login')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                <?php endif; ?>

                <?php endif; ?>

            </ul>

        </div>
    </div>
</nav>
<?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/layouts/inc/frontnav.blade.php ENDPATH**/ ?>