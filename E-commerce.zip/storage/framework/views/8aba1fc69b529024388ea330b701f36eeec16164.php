<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card" style="height: 500px">
            <div class="row">
                <div class="col-md-3 m-5">
                    <div class="card bg-danger">
                        <div class="card-body">
                            <h5 class="card-title">Total Orders </h5>
                            <p class="card-text" style="color: black"><b> Orders On Progress: <?php echo e($ordersProgress->count()); ?></b></p>
                            <p class="card-text" style="color: black"><b> Orders Finished: <?php echo e($ordersFinished->count()); ?></b></p>
                            <a href="<?php echo e(url('/orders')); ?>" class="card-link">Orders</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 m-5">
                    <div class="card bg-warning" style="width: 18rem;">
                        <div class="card-body">
                            <h5 class="card-title">Total Users : </h5>
                            <p class="card-text" style="color: black"><b><?php echo e($users->count()); ?></b></p>
                            <a href="<?php echo e(url('/users')); ?>" class="card-link">users</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 m-5">
                    <div class="card bg-danger" style="width: 18rem;">
                        <div class="card-body">
                            <h5 class="card-title">Total Products : </h5>
                            <p class="card-text" style="color: black"><b><?php echo e($products->count()); ?></b></p>
                            <a href="<?php echo e(url('/products')); ?>" class="card-link">Products</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mx-5">
                    <div class="card bg-primary" style="width: 18rem;">
                        <div class="card-body">
                            <h5 class="card-title">Total Categories : </h5>
                            <p class="card-text" style="color: black"><b><?php echo e($category->count()); ?></b></p>
                            <a href="<?php echo e(url('/categories')); ?>" class="card-link">Categories</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/admin/index.blade.php ENDPATH**/ ?>