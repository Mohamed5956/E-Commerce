<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4>Edit Category</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('categories/'.$category->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="name" style="border-bottom: 1px solid black;"
                        value="<?php echo e($category->name); ?>">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="slug">Slug</label>
                        <input type="text" class="form-control" name="slug" style="border-bottom: 1px solid black;"
                        value="<?php echo e($category->slug); ?>">
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="description">Description</label>
                        <textarea name="description" rows="3" class="form-control" style="border-bottom: 1px solid black;">
                            <?php echo e($category->description); ?>

                        </textarea>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="status">Status</label>
                        <input type="checkbox" name="status" style="border-bottom: 1px solid black;"
                        <?php echo e($category->status == '1' ? 'checked':''); ?>>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="popular">Popular</label>
                        <input type="checkbox" name="popular" style="border-bottom: 1px solid black;"
                        <?php echo e($category->popular == '1' ? 'checked':''); ?>>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="meta_title">Meta title</label>
                        <input type="text" class="form-control" name="meta_title" style="border-bottom: 1px solid black;"
                        value="<?php echo e($category->meta_title); ?>">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="meta_keyowrds">Meta keywords</label>
                        <input type="text" class="form-control" name="meta_keywords"
                        
                            style="border-bottom: 1px solid black;" value="<?php echo e($category->meta_keywords); ?>">
                    </div>

                    <div class="col-md-12 mb-3">
                        <label for="meta_desc">Description</label>
                        <textarea name="meta_desc" rows="3" class="form-control" style="border-bottom: 1px solid black;">
                            <?php echo e($category->meta_desc); ?>

                        </textarea>
                    </div>
                    <?php if($category->image): ?>
                        <img src="<?php echo e(asset('assets/uploads/category/'.$category->image)); ?>" alt="cat-image" class="cat-image">
                    <?php endif; ?>
                    <div class="col-md-12">
                        <input type="file" name="image" class="form-control" >
                    </div>

                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>


                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>