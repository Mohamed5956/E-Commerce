<?php $__env->startSection('title'); ?>
    Write Review
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if($verified_purchase->count() > 0): ?>
                    <h4>You are writing review for <?php echo e($product->name); ?></h4>
                    <form action="<?php echo e(url('/add-review')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="prod_id" value="<?php echo e($product->id); ?>">
                        <textarea name="user_review" class="form-control" rows="5" placeholder="Write a Review"></textarea>
                        <button type="submit" class="btn btn-primary mt-3">Submit Review</button>
                    </form>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <h5>You are not eligable to review this product </h5>
                        <p>
                            For the trustthowrthiness of the review , only customers who purchased
                            the product can write a review about the product.
                        </p>
                        <a href="<?php echo e(url('/')); ?>" class="btn btn btn-primary mt-3">Go to home page </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/frontend/reviews/index.blade.php ENDPATH**/ ?>