<?php $__env->startSection('title'); ?>
    Welcome to E-Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.inc.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <h2>Fetured Products</h2>
                <div class="owl-carousel featured-carousel owl-theme">
                    
                    <?php $__currentLoopData = $featured_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="card">
                                <img src="<?php echo e(asset('assets/uploads/products/' . $prod->image)); ?>" alt="Product-image"
                                    style="width:200px">
                                <div class="card-body">
                                    <h5><?php echo e($prod->name); ?></h5>
                                    <span class="float-start"><?php echo e($prod->original_price); ?></span>
                                    <span class="float-end"> <s> <?php echo e($prod->selling_price); ?> </s> </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <h2>Trending Categories</h2>
                <div class="owl-carousel featured-carousel owl-theme">
                    <?php $__currentLoopData = $trending_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">

                            <a href="<?php echo e(url('view-category/'.$cat->slug)); ?>">
                                <div class="card">
                                    <img src="<?php echo e(asset('assets/uploads/category/' . $cat->image)); ?>" alt="Category-image"
                                        style="width:200px;min-height:200px">
                                    <div class="card-body">
                                        <h5><?php echo e($cat->name); ?></h5>
                                        <p class="float-start"><?php echo e($cat->description); ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.featured-carousel').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            dots: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 3
                }
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/frontend/index.blade.php ENDPATH**/ ?>