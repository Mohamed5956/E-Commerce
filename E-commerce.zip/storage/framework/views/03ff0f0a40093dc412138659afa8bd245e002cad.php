<?php $__env->startSection('title'); ?>
    Edit Review
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4>You are writing review for <?php echo e($review->product->name); ?></h4>
                    <form action="<?php echo e(url('/update-review')); ?>" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="review_id" value="<?php echo e($review->id); ?>">
                        <textarea name="user_review" class="form-control" rows="5" placeholder="Write a Review">
                            <?php echo e($review->user_review); ?>

                        </textarea>
                        <button type="submit" class="btn btn-primary mt-3">Update Review</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/frontend/reviews/edit.blade.php ENDPATH**/ ?>