<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h3>Category</h3>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['id']); ?></td>
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e($item['description']); ?></td>
                    <td>
                        <img src="<?php echo e(asset('assets/uploads/category/'.$item['image'])); ?>" alt="" class="cat-image">
                    </td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo e(url('categories/'.$item['id'].'/edit')); ?>">Edit</a>
                        <form action="<?php echo e(url('categories/'.$item['id'])); ?>" method="post">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <input type="submit" class="btn btn-danger" value="Delete" />
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\iti\laravel Projects\E-commerce\resources\views/admin/category/index.blade.php ENDPATH**/ ?>